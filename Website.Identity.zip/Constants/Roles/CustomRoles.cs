﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Constants.Roles
{
    public static class CustomRoles
    {
        public const string INCIDENT_RESOLVERS = "IncidentResolvers";
    }
}
