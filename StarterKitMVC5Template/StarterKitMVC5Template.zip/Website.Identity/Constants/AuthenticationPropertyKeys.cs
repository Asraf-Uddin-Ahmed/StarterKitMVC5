﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Constants
{
    internal static class AuthenticationPropertyKeys
    {
        internal const string CLIENT_ID = "as:client_id";
        internal const string USER_NAME = "userName";
    }
}
