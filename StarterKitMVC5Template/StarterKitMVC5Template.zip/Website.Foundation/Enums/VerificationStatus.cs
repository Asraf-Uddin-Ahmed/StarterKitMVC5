﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Enums
{
    public enum VerificationStatus
    {
        VerificationCodeDoesNotExist,
        Success,
        Fail
    }
}
