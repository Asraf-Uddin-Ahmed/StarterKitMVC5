﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Core.Enums
{
    public enum SettingsType
    {
        String,
        Integer,
        Boolean,
        DateTime,
        Double,
        Xml
    }
}
