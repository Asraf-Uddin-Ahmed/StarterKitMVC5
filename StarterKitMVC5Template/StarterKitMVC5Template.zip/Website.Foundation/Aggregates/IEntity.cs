﻿using System;
namespace $safeprojectname$.Aggregates
{
    public interface IEntity
    {
        Guid ID { get; set; }
    }
}
