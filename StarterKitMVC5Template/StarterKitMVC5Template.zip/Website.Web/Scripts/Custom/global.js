﻿
var Website__Name = {
    ValidationMessage: {
        Bootstrap: function () { }
    },
    Loader: function () { }
};
