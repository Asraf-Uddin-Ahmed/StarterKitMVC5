﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Core.SearchData
{
    public abstract class EntitySearch
    {
        public Guid? ID { get; set; }
        //public Guid? CreatedByUserID { get; set; }
        //public Guid? UpdatedByUserID { get; set; }
        //public DateTime? CreationTimeFrom { get; set; }
        //public DateTime? CreationTimeTo { get; set; }
        //public DateTime? UpdateTimeFrom { get; set; }
        //public DateTime? UpdateTimeTo { get; set; }
    }
}
