﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Constants.Claims
{
    public static class PhoneNumberConfirmed
    {
        public const string CLAIM_TYPE = "PhoneNumberConfirmed";
        public static class CLAIM_VALUE
        {
            public const string TRUE = "1";
            public const string FALSE = "0";
        };
    }
}
